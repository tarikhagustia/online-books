<div bgcolor="#fff" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:100%;line-height:1.6em;height:100%;width:100%!important;margin:0;padding:0">
<table class="m_-7898253087281955955body-wrap" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:100%;line-height:1.6em;width:100%;margin:0;padding:20px" bgcolor="#fff">
  <tbody><tr>
    <td style="font-size:14px;line-height:20px">
    	<p>Hallo, <?php echo $full_name ?></p>
  	<p>
   Terima kasih telah Berpartisipasi untuk mendaftar di hidayatkampai.com . Untuk menyelesaikan proses pendaftaran,
   kami membutuhkan konfirmasi atas alamat email Anda.
   Mohon membuka tautan dibawah ini untuk mengkonfirmasi data anda di hidayatkampai.com
    </p>
  	<p>
      <a href="<?php echo base_url('user/activation/?key='. $key)?>">Konfirmasi email saya</a>
    </p>
    </td>
  </tr>
	<tr>
    <td>
      Terimakasih.
    </td>
	</tr>
</tbody></table>
