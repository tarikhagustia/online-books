<div class="portlet light tasks-widget ">
  <div class="portlet-title">
    <div class="caption">
      <span class="caption-subject font-green-haze bold uppercase">Berhasil Upload</span>
    </div>
  </div>
    <div class="portlet-body util-btn-margin-bottom-5">
      <div class="clearfix">
        <h3>Selamat Buku anda berhasil diupload , klik <a href="<?php echo base_url('dashboard/book/view/'. $book_name) ?>">Disini</a> Untuk Melihat buku anda</h3>
      </div>
    </div>
</div>
