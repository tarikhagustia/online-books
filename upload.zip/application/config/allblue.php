<?php

defined('BASEPATH') or exit('No direct script access allowed');
$config['vendor_name']  = "Allblue Technology";
$config['vendor_url']  = "http://allblue.technology";
$config['vendor_key']  = "90942ca317d192d19df29db92f54cfa8";
$config['vendor_default']  = 1234;
$config['vendor_hash'] = $config['vendor_name'] . $config['vendor_url'] . $config['vendor_key'];
$config['client_name'] = 'Baca Online';
$config['client_url'] = '';
