<?php
class TemplatesController extends MX_Controller
{
  public function __construct()
  {
    parent::__construct();
  }
}
 ?>
